#!/bin/sh
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ZIP="$DIR/polyanka-updated-2026-10-28.zip"
[ -f "$ZIP" ] || { echo "Не найден архив: $ZIP" >&2; exit 1; }
BASE="$DIR/polyanka-updated"
DEST="$BASE"
N=2
while [ -e "$DEST" ]; do DEST="$BASE-$N"; N=$((N + 1)); done
mkdir -p "$DEST"
unzip -q "$ZIP" -d "$DEST"
printf 'Готово! Проект распакован в: %s\n' "$DEST"
