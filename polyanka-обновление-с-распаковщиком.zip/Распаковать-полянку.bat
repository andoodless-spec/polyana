@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -Command "$root = Split-Path -Parent '%~f0'; $zip = Join-Path $root 'polyanka-updated-2026-10-28.zip'; if (!(Test-Path -LiteralPath $zip)) { Write-Host 'Не найден архив:' $zip -ForegroundColor Red; exit 2 }; $base = Join-Path $root 'polyanka-updated'; $dest = $base; $i = 2; while (Test-Path -LiteralPath $dest) { $dest = ($base + '-' + $i); $i++ }; Expand-Archive -LiteralPath $zip -DestinationPath $dest; Write-Host ''; Write-Host 'Готово! Проект распакован в:' $dest -ForegroundColor Green; Start-Process explorer.exe $dest"
if errorlevel 1 (
  echo Не удалось распаковать архив. Проверьте, что ZIP лежит рядом с этим файлом.
) else (
  echo.
  echo Распаковка завершена.
)
pause
